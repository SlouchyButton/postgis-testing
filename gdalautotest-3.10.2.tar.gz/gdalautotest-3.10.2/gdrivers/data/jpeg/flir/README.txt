FLIR.jpg: https://github.com/exiftool/exiftool/blob/master/t/images/FLIR.jpg
Image_thermique_de_l_emission_d_un_radiateur_a_travers_un_mur.jpg: https://upload.wikimedia.org/wikipedia/commons/9/92/Image_thermique_de_l%27%C3%A9mission_d%27un_radiateur_%C3%A0_travers_un_mur.jpg

References to other images in https://exiftool.org/forum/index.php?topic=4898.msg23511#msg23511:
https://commons.wikimedia.org/wiki/File:IRWater.jpg
https://commons.wikimedia.org/wiki/File:IR_Fussbodenheizung.jpg
