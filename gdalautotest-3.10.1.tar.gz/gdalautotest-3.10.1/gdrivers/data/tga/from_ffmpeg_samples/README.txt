Files coming from https://samples.ffmpeg.org/image-samples/ and attached to
https://github.com/OSGeo/gdal/issues/5168
